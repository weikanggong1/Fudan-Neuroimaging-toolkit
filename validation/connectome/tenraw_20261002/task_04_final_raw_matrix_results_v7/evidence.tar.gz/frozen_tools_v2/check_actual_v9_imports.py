import sys,pathlib,json,hashlib,socket,datetime
sys.dont_write_bytecode=True
p=pathlib.Path('/cwStorage/home/gongwk/Notebook_code/fnit_connectome_tenraw_20261002/formal_actual_comparison_helper_v9/tools/reference');sys.path.insert(0,str(p))
import benchmark_connectome_cohort_compare as compare
assert pathlib.Path(compare.__file__).resolve()==p/'benchmark_connectome_cohort_compare.py'
assert hashlib.sha256((p/'connectome_actual_gpu_origins.py').read_bytes()).hexdigest()=='7c19f5078e743656d5eea63d196197dce4931c1eea5cae348eefc77928bdc352'
assert hashlib.sha256((p/'connectome_actual_gpu_completed_subset.py').read_bytes()).hexdigest()=='9f74c83790ff14ad19bc7b432dd8d21b9245daf6fa67a4cdc8c54eeb0197220c'
d={'actual_hostname':socket.gethostname(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'actual v9 CPU imports only; no qualification or scientific calculation','module_sha256':{str(p/n):hashlib.sha256((p/n).read_bytes()).hexdigest() for n in ('benchmark_connectome_cohort_compare.py','compare_freesurfer_recon_outputs.py','connectome_actual_gpu_origins.py','connectome_actual_gpu_completed_subset.py')},'FNIT_or_torch_modules_imported':[n for n in sys.modules if n=='fnit' or n.startswith('fnit.') or n=='torch' or n.startswith('torch.')],'GPU_or_MRI_started':False}
assert not d['FNIT_or_torch_modules_imported'];q=pathlib.Path(__file__).parent/'actual_v9_imports.json';assert not q.exists();q.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
